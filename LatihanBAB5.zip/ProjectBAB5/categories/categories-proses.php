<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
    <?php 
    if(isset($_POST['simpan'])) {
        $categories = $_POST['categories'];
        $price = $_POST['price'];
        $description= $_POST['description'];
        $image = $_FILES['photo']['name'];

        echo
        'Categories : ' . $categories . 
        '<br> Price : ' . $price .
        '<br> Description : '. $description .
        '<br> File name : ' . $image;  
        }
    ?>
<body>

</body>
</html>